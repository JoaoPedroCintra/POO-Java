/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lista5.exe2;

/**
 *
 * @author danie
 */
public interface Professor extends Empregado{
    public void ensina();
}
