package lista5.exe1;
public interface JogadorFutebol {
    
    public void fazerCera();
    public void fazerGol();
    public void baterPenalti();
}
