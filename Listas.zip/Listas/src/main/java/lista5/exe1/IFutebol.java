/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author danie
 */
package lista5.exe1;
public interface IFutebol {
    // aqui apenas definimos os métodos de futebol
    // todos os métodos são abstratos
    public void chutar();
    public void cobrarEscanteio();
    public void cobrarPenalti();
    public void cabecear();
}
