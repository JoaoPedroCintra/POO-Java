package teste.exe1;

public interface Arqueiro {
    public void atirarFlechas();
}
