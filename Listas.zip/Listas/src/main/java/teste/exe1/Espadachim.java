package teste.exe1;

public interface Espadachim {
    public void brandirEspada();
}
