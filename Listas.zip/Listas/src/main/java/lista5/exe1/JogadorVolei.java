/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lista5.exe1;

public interface JogadorVolei {
    public void sacar();
    public void rodizio();
    public void cortar();
}
