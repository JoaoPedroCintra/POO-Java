package lista5.exe1;
public interface JogadorBasquete {
    
    public void arremessar();
    public void fazerBandeja();
    public void enterrar();
    
    
}
