/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista5.exe2;

/**
 *
 * @author danie
 */
public class TestaPessoa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pessoa objPessoa = new Pessoa();
        System.out.println(objPessoa.toString());
        objPessoa.come();
        objPessoa.ensina();
        objPessoa.pagaIR();
        objPessoa.respira();
        objPessoa.tiraCpf();
        objPessoa.tiraRg();
        objPessoa.trabalha();
        objPessoa.vota();
        System.out.println(objPessoa.toString());

        
    }
    
}
