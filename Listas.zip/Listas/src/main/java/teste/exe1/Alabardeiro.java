package teste.exe1;

public interface Alabardeiro {
    public void atacarComLanca();
}
