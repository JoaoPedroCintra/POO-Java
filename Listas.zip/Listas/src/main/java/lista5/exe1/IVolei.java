/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lista5.exe1;

/**
 *
 * @author danie
 */
public interface IVolei {
    public void sacar();
    public void bloquear();
    public void recepcionar();
    public void atacar();
}
