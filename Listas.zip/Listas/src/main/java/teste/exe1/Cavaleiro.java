package teste.exe1;

public interface Cavaleiro {
    public void avancar();
}
